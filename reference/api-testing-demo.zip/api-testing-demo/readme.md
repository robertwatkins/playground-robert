## Using Newman with Docker

### Running Just Newman (without Docker)
```
newman run rest-countries-parameterized.postman_collection.json -d demo-data.csv -e demo.postman_environment.json
```

**Newman Parameters**

'run' is the newman command to run a postman test. This command is followed by the location of the test

-d provides the data file used for the tests

-e provides the environment file used for the tests.

## Configuration
(note that [docker installation tasks](https://docs.docker.com/get-docker/) are a pre-requisite)

### One-time only
```
docker pull postman/newman
```

### Use Newman to run postman test Through Docker
```
docker run -v ~/code:/etc/newman -t postman/newman run rest-countries-parameterized.postman_collection.json -d demo-data.csv -e demo.postman_environment.json
```
This newman container is set up to expect all the files referenced to be in the /etc/newman folder within the container.

**Docker Parameters**

'run' that appears first is the docker command to run a container.

'-v' maps the local directory ('~/code' in this case) to the internal docker path /etc/newman. (Change this to your local path for these files to be able to run locally.)

'-t' points to the newman container we downloaded earlier with the 'docker pull' command

**Newman Parameters**

'run' that appears second is the newman command to run a postman test. This command is followed by the location of the test

### Use Newman to run tests and output results as json file
Now we can additionally save the output to a file that can then be further processed as part of a release pipeline, dashboard and/gor test execution result tracking system.

```
docker run -v ~/code:/etc/newman -t postman/newman run rest-countries-parameterized.postman_collection.json -d demo-data.csv -e demo.postman_environment.json --reporters cli,json --reporter-json-export outputfile.json
```
